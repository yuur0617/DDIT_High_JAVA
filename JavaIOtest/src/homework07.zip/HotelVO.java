package homework07;

import java.io.Serializable;

public class HotelVO implements Serializable{
	
		private String roomNum;	// 방번호
		private String name;	// 이름
		
		//생성자
		public HotelVO(String roomNum, String name) {
			super();
			this.name = name;
			this.roomNum = roomNum;
		}
		
		//name getter,setter
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		//roomNum getter,setter
		public String getRoomNum() {
			return roomNum;
		}
		public void setRoomNum(String roomNum) {
			this.roomNum = roomNum;
		}

		// toString
		@Override
		public String toString() {
			return "HotelVO [name=" + name + ", roomNum=" + roomNum + "]";
		}
}

